Quvonchbek — Premium NFC/QR Digital Vizitka

FAYLLAR:
- index.html  → sahifa
- quvonchbek_rustamov.vcf → kontakt (Add to Contacts)
- qr_vcard.png → QR (vCard)
- README.txt → yo‘riqnoma

1) Hosting (eng oson usul) — Netlify Drop:
   1. https://app.netlify.com/drop ga kiring
   2. Shu ZIP ichidagi fayllarni (yoki ZIPni ochib) drag&drop qiling
   3. Sizga tayyor link beradi (masalan: https://xxxxx.netlify.app)

2) NFC tag/karta yozish:
   Android:
   - NFC Tools → Write → URL → (hosting link) → Write → tagga tekkizing

   iPhone:
   - iOS’da NFC yozish uchun NFC tag app kerak bo‘ladi (NFC Tools iOS yoki “NFC TagWriter” turidagi app).
   - Eng osoni: NFC kartani yozib beradigan joyda sizning hosting linkingizni yozdirib oling.

3) Tavsiya:
   - NFC ichiga VCF emas, aynan SAHIFA LINKini yozing.
   - QR esa kontaktni tez saqlash uchun (qr_vcard.png) ishlaydi.
